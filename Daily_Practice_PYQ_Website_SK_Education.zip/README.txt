# Daily Practice PYQ — SK Education
इस संस्करण में अपलोड किए गए SK Education लोगो/मोहर और Sushant Yadav (Director) के हस्ताक्षर को Certificate में जोड़ा गया है।
`index.html` को Chrome में खोलकर वेबसाइट चलाएँ।
